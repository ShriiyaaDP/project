<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<?php include 'assets/include/analytics.php';?>
  
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>DHATRI PATRA | Home </title>
    <!-- web fonts -->
    <link href="http://fonts.googleapis.com/css?family=Karla:400,700&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <!-- //web fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-freedom.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.2/owl.carousel.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  </head>
  <body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<div id="codefund"><!-- fallback content --></div>
<script src="../../../../../../../codefund.io/properties/441/funder.js" async="async"></script>

<!-- Global site tag (gtag.js) - Google Analytics Removed -->
    
<meta name="robots" content="noindex">
<body>

<!-- New toolbar-->
<style>
* {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}


#vgbcsDemoBar.vgbcs-demo-bar {
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 9999;
  padding: 40px 5px;
  padding-top:70px;
  margin-bottom: 70px;
  background: #0D1326;
  border-top-left-radius: 9px;
  border-bottom-left-radius: 9px;
}

#vgbcsDemoBar.vgbcs-demo-bar a {
  display: block;
  color: #e6ebff;
  text-decoration: none;
  line-height: 24px;
  opacity: .6;
  margin-bottom: 20px;
  text-align: center;
}

#vgbcsDemoBar.vgbcs-demo-bar span.vgbcs-icon {
  display: block;
}

#vgbcsDemoBar.vgbcs-demo-bar a:hover {
  opacity: 1;
}

#vgbcsDemoBar.vgbcs-demo-bar .vgbcs-icon svg {
  color: #e6ebff;
}
#vgbcsDemoBar.vgbcs-demo-bar .responsive-icons {
  margin-top: 30px;
  border-top: 1px solid #41414d;
  padding-top: 40px;
}
#vgbcsDemoBar.vgbcs-demo-bar .demo-btns {
  border-top: 1px solid #41414d;
  padding-top: 30px;
}
#vgbcsDemoBar.vgbcs-demo-bar .responsive-icons a span.fa {
  font-size: 26px;
}
#vgbcsDemoBar.vgbcs-demo-bar .no-margin-bottom{
  margin-bottom:0;
}
.toggle-right-sidebar span {
  background: #0D1326;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #e6ebff;
  border-radius: 50px;
  font-size: 26px;
  cursor: pointer;
  opacity: .5;
}
.pull-right {
  float: right;
  position: fixed;
  right: 0px;
  top: 70px;
  width: 90px;
  z-index: 99999;
  text-align: center;
}
/* ============================================================
RIGHT SIDEBAR SECTION
============================================================ */

#right-sidebar {
  width: 90px;
  position: fixed;
  height: 100%;
  z-index: 1000;
  right: 0px;
  top: 0;
  margin-top: 60px;
  -webkit-transition: all .5s ease-in-out;
  -moz-transition: all .5s ease-in-out;
  -o-transition: all .5s ease-in-out;
  transition: all .5s ease-in-out;
  overflow-y: auto;
}

/* ============================================================
RIGHT SIDEBAR TOGGLE SECTION
============================================================ */

.hide-right-bar-notifications {
  margin-right: -300px !important;
  -webkit-transition: all .3s ease-in-out;
  -moz-transition: all .3s ease-in-out;
  -o-transition: all .3s ease-in-out;
  transition: all .3s ease-in-out;
}

/*===============================================
carsouel silder
=================================================*/
.carousel-inner img {
    width: 100%;
    height: 100%;


@media (max-width: 992px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.desktop-mode{
      display: none;

  }
}
@media (max-width: 767px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.tablet-mode{
      display: none;

  }
}
@media (max-width: 568px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.mobile-mode{
      display: none;
  }
  #vgbcsDemoBar.vgbcs-demo-bar .responsive-icons {
      margin-top: 0px;
      border-top: none;
      padding-top: 0px;
  }
  #right-sidebar,.pull-right {
      width: 90px;
  }
  #vgbcsDemoBar.vgbcs-demo-bar .no-margin-bottom-mobile{
      margin-bottom: 0;
  }
}
</style>
 <?php include 'assets/include/navbar1.php';?>
<!------slider code-------------->
<section class="vgbcs-main-slider" id="home">
  <!-- main-slider -->
  <div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="1.png" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
        <a class="btn btn-secondary btn-theme2 mt-3" href="">Donate Now</a>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="2.png" alt="Chicago" width="1100" height="500">
      <div class="carousel-caption">
        <a class="btn btn-secondary btn-theme2 mt-3" href="https://forms.gle/sH6irPUDCRoaTSi28"> Join Us</a>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="3.png" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <a class="btn btn-secondary btn-theme2 mt-3" href="contact.php">Contact Us</a>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<!------- end of new---------->
  <!-- //script -->
  <!-- /main-slider -->
</section>
<!---728x90--->
<section class="vgbcs-feature-2">
	<div class="grid top-bottom py-5">
		<div class="container py-md-5">
			<div class="heading text-center mx-auto">
				<h3 class="head">We Can Change The World</h3>
				<p class="my-3 head"> “Never Doubt that a small group of thoughtful, committed youths can change
the world. Indeed it’s the only thing that ever has.”<br></p>
<p style="color:darkred;">This defines - Dhatri Patra</p>

			</div>
			<div class="middle-section row mt-5 pt-3">
				<div class="three-grids-columns col-md-4">

					<h4 ><span>01</span> Mission</h4>
					<p >To develop appropriate programs to generate and raise funds for development .</p><br><br>
				</div>
				<div class="three-grids-columns col-md-4 mt-md-0 mt-5">

					<h4 ><span>02</span> Vision</h4>
					<p >To help create an environment with equal opportunity the development of the Children, Family and Communities</p><br>

				</div>
				<div class="three-grids-columns col-md-4 mt-md-0 mt-5">

					<h4 ><span>03</span> Values</h4>
					<p >To support the education of orphans,brilliant but needy Children <br>To support the development of deprived Communities.</p>
				</div>

			</div>
		</div>
	</div>
</section>
<!---728x90--->

 <section class="block-5 pb-5">
    <div class="container pb-md-5">
        <section class="timeline row">
            <div class="col-lg-4">
                <div class="tl-item">
                    <div class="tl-bg" style="background-image: url(assets/images/education2.jpg)"></div>
                    <div class="tl-content">
                        <h1>Help Children</h1>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 my-4 my-lg-0">
                <div class="tl-item">
                    <div class="tl-bg" style="background-image: url(assets/images/donation1.jpg)"></div>
                    <div class="tl-content">
                        <h1 class="f3 text--accent ttu">Development Matters</h1>

                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="tl-item">
                    <div class="tl-bg" style="background-image: url(assets/images/Dog.jpg)"></div>
                    <div class="tl-content">
                        <h1 class="f3 text--accent ttu">Environment</h1>

                    </div>
                </div>
            </div>
        </section>
    </div>
</section>
<!---728x90--->

<!-- specifications -->
<section class="vgbcs-specifications-9">
    <div class="main-w3 py-5" id="stats">
        <div class="container py-md-5">
            <div class="main-cont-wthree-fea row">
                <div class="grids-speci1 col-lg-3 col-6 text-center">
                    <div class="spec-2">

                        <h3 class="title-spe">60+</h3>
                        <p>Donations</p>
                    </div>
                </div>
                <div class="grids-speci1 midd-eff-spe col-lg-3 col-6 text-center">
                    <div class="spec-2">

                        <h3 class="title-spe">60+</h3>
                        <p>Volunteers</p>
                    </div>
                </div>
                <div class="grids-speci1 las-but col-lg-3 col-6  mt-lg-0 mt-4 text-center">
                    <div class="spec-2">

                        <h3 class="title-spe">6</h3>
                        <p>Campaigns Conducted</p>
                    </div>
                </div>
                <div class="grids-speci1 las-t col-lg-3 col-6  mt-lg-0 mt-4 text-center">
                    <div class="spec-2">

                        <h3 class="title-spe">1200+</h3>
                        <p>Food Distributed</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- //specifications -->
</section>
<!-- features-4 block -->
<section class="vgbcs-index1" id="about">
	<div class="calltoaction-20  py-5 editContent">
		<div class="container py-md-3">
			<div class="heading text-center mx-auto">
				<h3 class="head">Join Us</h3>
				<p class="my-3 head"> </p>
			</div>
			<div class="calltoaction-20-content row mt-5 pt-3">
				<div class="column center-align-self col-lg-12 py-4 py-lg-5 pl-4 pl-lg-5 pr-4 pr-lg-5">
					<h5 class="editContent">Become a Volunteer</h5>
					<p class="more-gap editContent"></p>

					<a href="https://forms.gle/sH6irPUDCRoaTSi28" class="theme-button btn mt-4">Sign Up</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- features-4 block -->
<!--customers-7-->
<section class="vgbcs-customers-8" id="testimonials">
    <div class="customers_sur py-5">
        <div class="container py-md-5">
            <div class="heading text-center mx-auto">
                <h3 class="head text-white">Words From Our Clients</h3>
                <p class="my-3 head text-white"> I Can't Change the direction of the wind,But i can adjust my sails to always reach my destination</p>
            </div>
            <div class="customers-top_sur row mt-5 pt-3">
                <div class="customers-left_sur col-md-4">
                    <div class="customers_grid">
                        <h4>Humanity</h4>
                        <p class="sub-test">"An individual has not started living until he can rise above the narrow confines of his individualistic concerns to the broader concerns of all humanity.”<br> </p>
                    </div>
                    <div class="customers-bottom_sur row">
                        <div class="custo-img-res col-3">
                            <img src="assets/images/photo.jpg" alt=" " class="img-responsive">
                        </div>
                        <div class="custo_grid col-9">
                            <h5 class="text-white">Raghavendra M</h5>
                            <span>President</span>
                        </div>

                    </div>
                </div>
                <div class="customers-middle_sur col-md-4 mt-md-0 mt-4">
                    <div class="customers_grid">
                        <h4>Funding</h4>
                        <!-- <p class="sub-test">“The problem is that rich are getting richer by not giving and poor and getting poorer by not receiving.”<br><br>"Effort, great, small.”</p> -->
                        <p class="sub-test">“The value of money isn't what it can buy, but how many it can help. It is the duty of the previlidged to support the underpreviledged”<br>"Every penny matters”</p>
                    </div>
                    <div class="customers-bottom_sur row">
                        <div class="custo-img-res col-3">
                            <img src="assets/images/photo2.jpg" alt=" " class="img-responsive">
                        </div>
                        <div class="custo_grid col-9">
                            <h5 class="text-white">Varun Govind</h5>
                            <span>Volunteer</span>
                        </div>

                    </div>
                </div>
                <div class="customers-middle_sur col-md-4 mt-md-0 mt-4">
                    <div class="customers_grid">
                        <h4>Kindness</h4>
                        <p class="sub-test">“Love and kindness are never wasted. They always make a difference. They bless the one who receives them, and they bless you, the giver.“Be kind whenever possible. It is always possible.” <br></p>
                    </div>
                    <div class="customers-bottom_sur row">
                        <div class="custo-img-res col-3">
                            <img src="assets/images/photo1.jpg" alt=" " class="img-responsive">
                        </div>
                        <div class="custo_grid col-9">
                            <h5 class="text-white">Karan Khadka</h5>
                            <span>Guest</span>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--//customers-7-->
<section class="grids-4" id="news">
    <div id="grids4-block" class="py-5">
        <div class="container py-md-5">
            <div class="heading text-center mx-auto">
                <h3 class="head">WE WORK FOR</h3>
            </div>
            <div class="row mt-5 pt-3">
                <div class="grids4-info  col-lg-4 col-md-6">

                    <div class="info-bg editContent">
                        <a href="blog.html"><img src="assets/images/FoodDonation.jpg" class="img-fluid" alt=""></a>
                        <h5 class="mt-4 mb-1 editContent"><a class="editContent" href="blog.html">Distribution of food to the homeless</a>
                        </h5>
                        <li><a href="#blog.html"> Read More</a></li>
                    </div>
                </div>
                <div class="grids4-info col-lg-4 col-md-6 mt-md-0 mt-4">

                    <div class="info-bg editContent">
                        <a href="blog.html"><img src="assets/images/education3.jpg" class="img-fluid" alt=""></a>
                        <h5 class="mt-4 mb-1 editContent"><a class="editContent" href="blog.html">Basic education for underprivileged
                            </a></h5>
                            <li><a href="#"> Read More</a></li>
                    </div>
                </div>
                <div class="grids4-info col-lg-4 col-md-6 offset-lg-0 offset-md-3 mt-lg-0 mt-4">

                    <div class="info-bg editContent">
                        <a href="blog.html"><img src="assets/images/dog1.jpg" class="img-fluid" alt=""></a>
                        <h5 class="mt-4 mb-1 editContent"><a class="editContent" href="blog.html">Care for Dogs</a></h5>
                        <li><a href="#"> Read More</a></li>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="vgbcs-forms-9" id="subscribe">
    <div class="main-w3 py-5">
        <div class="container py-md-5">
            <div class="grids-forms">
                <div class="main-midd">
                    <h4 class="title-head">Subscribe to our community</h4>
                    <p class="para">To get weekly updates on the activities to be performed, Subscribe to our website</p>
                </div>
                <div class="main-midd-2">
                    <form method="POST" class="rightside-form">
                      <?php include 'assets/include/subscribe.php';?>
                        <input type="email" name="email" placeholder="Enter your email" required="">
                        <button class="btn action-button btn-primary" value="Sent" type="submit">Subscribe</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- grids block 5 -->
<section class="vgbcs-footer-29-main">
  <div class="footer-29">
    <div class="container">
      <div class="d-grid grid-col-4 footer-top-29">
        <div class="footer-list-29 footer-1">
          <img src="assets/images/logoinv.png" style="height:70px;" >
          <p>“Never Doubt that a small group of thoughtful, committed youths can change the world. Indeed it’s the only thing that ever has.” </p>

        </div>
        <div class="footer-list-29 footer-2">
          <ul>
            <h6 class="footer-title-29">Categories</h6>
            <li><a href="contact.php">Charity </a></li>
            <li><a href="contact.php">Donations</a></li>
            <li><a href="contact.php">Internship</a></li>
            <li><a href="contact.php">Join us</a></li>
            <li><a href="contact.php">Help</a></li>
          </ul>
        </div>

        <div class="footer-list-29 footer-3">


            <h6 class="footer-title-29">Latest Posts</h6>
            <ul class="list-unstyled d-flex flex-wrap">
              <li class="">
                <div class="row">
                  <a class="col-md-5 col-4" href="#">
                    <img class="rounded img-fluid img-responsive" src="assets/images/Dog.jpg" alt="image">
                  </a>
                  <div class="col pl-0">
                    <a class="footer-small-text" href="#">Tying Reflecting Belts for Stray Dogs </a>
                    <div class="text-sub-small text-white mt-2">January 2nd, 2022</div>
                  </div>
                </div>
              </li>
              <li class="mt-md-0 mt-2">
                <div class="row my-2 my-md-3">
                  <a class="col-md-5 col-4" href="#">
                    <img class="rounded img-fluid img-responsive" src="assets/images/food1.jpg" alt="image">
                  </a>
                  <div class="col pl-0">
                    <a class="footer-small-text" href="#">Food Donation near Kristu Jayanti College </a>
                    <div class="text-sub-small text-white mt-2">January 16th, 2022 </div>
                  </div>
                </div>
              </li>
            </ul>


        </div>
        <div class="footer-list-29 footer-4">
          <ul>
            <h6 class="footer-title-29">Quick Links</h6>
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </div>
      </div>
      <div class="d-grid grid-col-2 bottom-copies">
        <p class="copy-footer-29">© 2022 Dhatri Patra. All rights reserved.</p>
          <!--<a href="https://vgbcsayouts.com/">vgbcsayouts</a></p>-->
            <div class="main-social-footer-29">
              <a href="https://www.facebook.com/qr/107036761857349" class="facebook"><span class="fa fa-facebook"></span></a>
            <!--  <a href="#twitter" class="twitter"><span class="fa fa-twitter"></span></a>-->
              <a href="https://www.instagram.com/dhatripatra/?r=nametag" class="instagram"><span class="fa fa-instagram"></span></a>
            <a href="https://youtube.com/channel/UCBXDeqDvuD3-xTuZqQ1x9kQ"><span class="fab fa-youtube"></span></a>
              <!---<a href="#google-plus" class="google-plus"><span class="fa fa-google-plus"></span></a>-->
             <!--- <a href="#linkedin" class="linkedin"><span class="fa fa-linkedin"></span></a>--->
            </div>
      </div>
    </div>
  </div>
  <!-- move top -->
  <button onclick="topFunction()" id="movetop" title="Go to top">
    <span class="fa fa-angle-up"></span>
  </button>
  <script>
    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function () {
      scrollFunction()
    };

    function scrollFunction() {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("movetop").style.display = "block";
      } else {
        document.getElementById("movetop").style.display = "none";
      }
    }

    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }
  </script>
  <!-- /move top -->
</section>
<!-- //footer-28 block -->
</section>
<script>
  $(function () {
    $('.navbar-toggler').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../../../../../../../code.jquery.com/jquery-3.4.1.slim.min.js"
  integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
</script>
<script src="../../../../../../../cdn.jsdelivr.net/npm/popper.js%401.16.0/dist/umd/popper.min.js"
  integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
</script>
<script src="../../../../../../../stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
  integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
</script>

<!-- Template JavaScript -->
<script src="assets/js/all.js"></script>


<!-- script for -->
<script>
  $(document).ready(function () {
    $('.owl-one').owlCarousel({
      loop: true,
      margin: 0,
      nav: true,
      responsiveClass: true,
      autoplay: false,
      autoplayTimeout: 5000,
      autoplaySpeed: 1000,
      autoplayHoverPause: false,
      responsive: {
        0: {
          items: 1,
          nav: false
        },
        480: {
          items: 1,
          nav: false
        },
        667: {
          items: 1,
          nav: true
        },
        1000: {
          items: 1,
          nav: true
        }
      }
    })
  })
</script>
<!-- //script -->
<!--quantity-->
<script>
  $('.value-plus').on('click', function () {
    var divUpd = $(this).parent().find('.value'),
      newVal = parseInt(divUpd.text(), 10) + 1;
    divUpd.text(newVal);
  });

  $('.value-minus').on('click', function () {
    var divUpd = $(this).parent().find('.value'),
      newVal = parseInt(divUpd.text(), 10) - 1;
    if (newVal >= 1) divUpd.text(newVal);
  });
</script>
<!--//quantity-->

<!-- jQuery-Photo-filter-lightbox-portfolio-plugin -->
<script src="assets/js/jquery.quicksand.js"></script>
<script src="assets/js/script.js"></script>
<script src="assets/js/jquery.prettyPhoto.js"></script>
<!-- //jQuery-Photo-filter-lightbox-portfolio-plugin -->


<div id = "v-vgbcsayouts"></div><script>(function(v,d,o,ai){ai=d.createElement('script');ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, '../../../../../../../a.vdo.ai/core/v-vgbcsayouts/vdo.ai.js');</script>
	</body>


</html>
