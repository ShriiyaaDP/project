<!-- grids block 5 -->
<section class="vgbcs-footer-29-main">
  <div class="footer-29">
    <div class="container">
      <div class="d-grid grid-col-4 footer-top-29">
        <div class="footer-list-29 footer-1">
          <img src="assets/images/logoinv.png" style="height:70px;" >
          <p>“Never Doubt that a small group of thoughtful, committed youths can change the world. Indeed it’s the only thing that ever has.” </p>

        </div>
        <div class="footer-list-29 footer-2">
          <ul>
            <h6 class="footer-title-29">Categories</h6>
            <li><a href="contact.php">Partner with Us</a></li>
            <li><a href="https://rzp.io/l/P6pOEI09kZ">Donate</a></li>
            <li><a href="internship.php">Internship</a></li>
            <li><a href="contact.php">Join us</a></li>
            <li><a href="contact.php">Help</a></li>
          </ul>
        </div>

        <!-- <div class="footer-list-29 footer-3">
            <h6 class="footer-title-29">Latest Posts</h6>
            <ul class="list-unstyled d-flex flex-wrap">
              <li class="">
                <div class="row">
                  <a class="col-md-5 col-4" href="#">
                    <img class="rounded img-fluid img-responsive" src="assets/images/dog123.jpg" alt="image">
                  </a>
                  <div class="col pl-0">
                    <a class="footer-small-text" href="https://dhatripatra.blogspot.com/2022/04/tieing-reflective-bands-to-stary-dogs.html">Tying Reflecting Belts for Stray Dogs </a>
                    <div class="text-sub-small text-white mt-2">January 2nd, 2022</div>
                  </div>
                </div>
              </li>
              <li class="mt-md-0 mt-2">
                <div class="row my-2 my-md-3">
                  <a class="col-md-5 col-4" href="#">
                    <img class="rounded img-fluid img-responsive" src="assets/images/food1.jpg" alt="image">
                  </a>
                  <div class="col pl-0">
                    <a class="footer-small-text" href="https://dhatripatra.blogspot.com/2022/04/food-donation_9.html">Food Donation near Kristu Jayanti College </a>
                    <div class="text-sub-small text-white mt-2">January 16th, 2022 </div>
                  </div>
                </div>
              </li>
            </ul> 


         </div> -->
         <div class="footer-list-29 footer-3">
          <ul>
            <h6 class="footer-title-29">Payment Policy</h6>
            <li><a href="https://merchant.razorpay.com/policy/KK4kvH62QkEdZs/terms">Terms & Conditions</a></li>
            <li><a href="https://merchant.razorpay.com/policy/KK4kvH62QkEdZs/refund">Cancellation & Refund Policy</a></li>
            <li><a href="https://merchant.razorpay.com/policy/KK4kvH62QkEdZs/privacy">Privacy Policy</a></li>
            <li><a href="https://merchant.razorpay.com/policy/KK4kvH62QkEdZs/shipping">Shipping & Delivery Policy</a></li>
          </ul>
        </div>
        <div class="footer-list-29 footer-4">
          <ul>
            <h6 class="footer-title-29">Quick Links</h6>
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="https://dhatripatra.blogspot.com/">Blog</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </div>
      </div>
      <div class="d-grid grid-col-2 bottom-copies">
        <p class="copy-footer-29">© 2022 Dhatri Patra. All rights reserved.</p>
          <!--<a href="https://vgbcsayouts.com/">vgbcsayouts</a></p>-->
            <div class="main-social-footer-29">
              <a href="https://www.facebook.com/qr/107036761857349" class="facebook"><span class="fa fa-facebook"></span></a>
            <!--  <a href="#twitter" class="twitter"><span class="fa fa-twitter"></span></a>-->
              <a href="https://www.instagram.com/dhatripatra/?r=nametag" class="instagram"><span class="fa fa-instagram"></span></a>
            <a href="https://youtube.com/channel/UCBXDeqDvuD3-xTuZqQ1x9kQ"><span class="fab fa-youtube"></span></a>
              <!---<a href="#google-plus" class="google-plus"><span class="fa fa-google-plus"></span></a>-->
             <!--- <a href="#linkedin" class="linkedin"><span class="fa fa-linkedin"></span></a>--->
            </div>
      </div>
    </div>
  </div>
  <!-- move top -->
  <button onclick="topFunction()" id="movetop" title="Go to top">
    <span class="fa fa-angle-up"></span>
  </button>
  <script>
    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function () {
      scrollFunction()
    };

    function scrollFunction() {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("movetop").style.display = "block";
      } else {
        document.getElementById("movetop").style.display = "none";
      }
    }

    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }
  </script>
  <!-- /move top -->
</section>
<!-- //footer-28 block -->
</section>
<script>
  $(function () {
    $('.navbar-toggler').click(function () {
      $('body').toggleClass('noscroll');
    })
  });
</script>
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="../../../../../../../code.jquery.com/jquery-3.4.1.slim.min.js"
  integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
</script>
<script src="../../../../../../../cdn.jsdelivr.net/npm/popper.js%401.16.0/dist/umd/popper.min.js"
  integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
</script>
<script src="../../../../../../../stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
  integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
</script>

<!-- Template JavaScript -->
<script src="assets/js/all.js"></script>


<!-- script for -->
<script>
  $(document).ready(function () {
    $('.owl-one').owlCarousel({
      loop: true,
      margin: 0,
      nav: true,
      responsiveClass: true,
      autoplay: false,
      autoplayTimeout: 5000,
      autoplaySpeed: 1000,
      autoplayHoverPause: false,
      responsive: {
        0: {
          items: 1,
          nav: false
        },
        480: {
          items: 1,
          nav: false
        },
        667: {
          items: 1,
          nav: true
        },
        1000: {
          items: 1,
          nav: true
        }
      }
    })
  })
</script>
<!-- //script -->
<!--quantity-->
<script>
  $('.value-plus').on('click', function () {
    var divUpd = $(this).parent().find('.value'),
      newVal = parseInt(divUpd.text(), 10) + 1;
    divUpd.text(newVal);
  });

  $('.value-minus').on('click', function () {
    var divUpd = $(this).parent().find('.value'),
      newVal = parseInt(divUpd.text(), 10) - 1;
    if (newVal >= 1) divUpd.text(newVal);
  });
</script>
<!--//quantity-->

<!-- jQuery-Photo-filter-lightbox-portfolio-plugin -->
<script src="assets/js/jquery.quicksand.js"></script>
<script src="assets/js/script.js"></script>
<script src="assets/js/jquery.prettyPhoto.js"></script>
<!-- //jQuery-Photo-filter-lightbox-portfolio-plugin -->


<div id = "v-vgbcsayouts"></div><script>(function(v,d,o,ai){ai=d.createElement('script');ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, '../../../../../../../a.vdo.ai/core/v-vgbcsayouts/vdo.ai.js');</script>