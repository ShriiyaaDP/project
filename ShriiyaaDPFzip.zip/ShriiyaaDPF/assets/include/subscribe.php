<?php
    require 'vendor/autoload.php';
    use PHPMailer\PHPMailer\PHPMailer;
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'smtp.hostinger.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->Username = 'mailer@dhatripatra.org';
    $mail->Password = 'Mail@sent235';
    $mail->setFrom('mailer@dhatripatra.org', 'Dhatri Patra');
    $mail->addAddress('support@dhatripatra.org', 'Support Dhatri Patra');
    $mail->addAddress($_POST['email'],$_POST['email']);
    if ($mail->addReplyTo($_POST['email'], $_POST['email'])) {
        $mail->Subject = 'Subscribed at Dhatri Patra';
        $mail->isHTML(false);
        $mail->Body = <<<EOT
            Hi There,
            
                You have successfully subscribed to Dhatri Patra 
                Email: {$_POST['email']}
            
                Please click on the below link to register as a volunteer.
                https://forms.gle/sH6irPUDCRoaTSi28
            Regard,
            Team Dhatri Patra
            https://dhatripatra.org/

        EOT;
        if (!$mail->send()) {
            echo '<script>alert("Sorry, something went wrong. Please try again later.");</script>';
        } else {
            echo '<script>alert("Subscribed Successfully! Thanks for contacting us.");</script>';
        }
    } 
?>