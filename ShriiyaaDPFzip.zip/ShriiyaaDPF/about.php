<!doctype html>
<html lang="en">
<head>
<?php include 'assets/include/analytics.php';?>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="ha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>   
  <!-- Required meta tags -->
  <link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">  
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Dhatri Patra| About</title>
    <!-- web fonts -->
    <link href="http://fonts.googleapis.com/css?family=Karla:400,700&amp;display=swap" rel="stylesheet">
    <!-- //web fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-freedom.css">
  </head>
  <body>
<script src='../../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:vgbcsayoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:vgbcsayoutscom');
  	}
})();
</script>
<!--<script>(function(v,d,o,ai){ai=d.createElement("script");ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, "//a.vdo.ai/core/vgbcsayouts_V2/vdo.ai.js?vdo=34");</script>-->
<div id="codefund"><!-- fallback content --></div>
<script src="../../../../../../../codefund.io/properties/441/funder.js" async="async"></script>

<!-- Global site tag (gtag.js) - Google Analytics Removed -->
<script async src='../../../../../../js/autotrack.js'></script>

<meta name="robots" content="noindex">
<body>
	<!-- Demo bar start -->
  <link rel="stylesheet" href="../../../../../../assests/css/font-awesome.min.css">
<!-- New toolbar-->
<style>
* {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}


#vgbcsDemoBar.vgbcs-demo-bar {
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 9999;
  padding: 40px 5px;
  padding-top:70px;
  margin-bottom: 70px;
  background: #0D1326;
  border-top-left-radius: 9px;
  border-bottom-left-radius: 9px;
}

#vgbcsDemoBar.vgbcs-demo-bar a {
  display: block;
  color: #e6ebff;
  text-decoration: none;
  line-height: 24px;
  opacity: .6;
  margin-bottom: 20px;
  text-align: center;
}

#vgbcsDemoBar.vgbcs-demo-bar span.vgbcs-icon {
  display: block;
}

#vgbcsDemoBar.vgbcs-demo-bar a:hover {
  opacity: 1;
}

#vgbcsDemoBar.vgbcs-demo-bar .vgbcs-icon svg {
  color: #e6ebff;
}
#vgbcsDemoBar.vgbcs-demo-bar .responsive-icons {
  margin-top: 30px;
  border-top: 1px solid #41414d;
  padding-top: 40px;
}
#vgbcsDemoBar.vgbcs-demo-bar .demo-btns {
  border-top: 1px solid #41414d;
  padding-top: 30px;
}
#vgbcsDemoBar.vgbcs-demo-bar .responsive-icons a span.fa {
  font-size: 26px;
}
#vgbcsDemoBar.vgbcs-demo-bar .no-margin-bottom{
  margin-bottom:0;
}
.toggle-right-sidebar span {
  background: #0D1326;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #e6ebff;
  border-radius: 50px;
  font-size: 26px;
  cursor: pointer;
  opacity: .5;
}
.pull-right {
  float: right;
  position: fixed;
  right: 0px;
  top: 70px;
  width: 90px;
  z-index: 99999;
  text-align: center;
}
/* ============================================================
RIGHT SIDEBAR SECTION
============================================================ */

#right-sidebar {
  width: 90px;
  position: fixed;
  height: 100%;
  z-index: 1000;
  right: 0px;
  top: 0;
  margin-top: 60px;
  -webkit-transition: all .5s ease-in-out;
  -moz-transition: all .5s ease-in-out;
  -o-transition: all .5s ease-in-out;
  transition: all .5s ease-in-out;
  overflow-y: auto;
}

/* ============================================================
RIGHT SIDEBAR TOGGLE SECTION
============================================================ */

.hide-right-bar-notifications {
  margin-right: -300px !important;
  -webkit-transition: all .3s ease-in-out;
  -moz-transition: all .3s ease-in-out;
  -o-transition: all .3s ease-in-out;
  transition: all .3s ease-in-out;
}



@media (max-width: 992px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.desktop-mode{
      display: none;

  }
}
@media (max-width: 767px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.tablet-mode{
      display: none;

  }
}
@media (max-width: 568px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.mobile-mode{
      display: none;
  }
  #vgbcsDemoBar.vgbcs-demo-bar .responsive-icons {
      margin-top: 0px;
      border-top: none;
      padding-top: 0px;
  }
  #right-sidebar,.pull-right {
      width: 90px;
  }
  #vgbcsDemoBar.vgbcs-demo-bar .no-margin-bottom-mobile{
      margin-bottom: 0;
  }
}
</style>
<!--<div class="pull-right toggle-right-sidebar">
<span class="fa title-open-right-sidebar tooltipstered fa-angle-double-right"></span>
</div>-->

<!--<div id="right-sidebar" class="right-sidebar-notifcations nav-collapse">
<div class="bs-example bs-example-tabs right-sidebar-tab-notification" data-example-id="togglable-tabs">

    <div id="vgbcsDemoBar" class="vgbcs-demo-bar">
        <div class="demo-btns">
        <a href="https://vgbcsayouts.com/?p=41702">
            <span class="vgbcs-icon -back">
                <span class="fa fa-arrow-left"></span>
            </span>
            <span class="vgbcs-text">Back</span>
        </a>
        <a href="https://vgbcsayouts.com/?p=41702">
            <span class="vgbcs-icon -download">
                <span class="fa fa-download"></span>
            </span>
            <span class="vgbcs-text">Download</span>
        </a>
        <a href="https://vgbcsayouts.com/checkout/?add-to-cart=41702" class="no-margin-bottom-mobile">
            <span class="vgbcs-icon -buy">
                <span class="fa fa-shopping-cart"></span>
            </span>
            <span class="vgbcs-text">Buy</span>
        </a>
    </div>
        <div class="responsive-icons">
            <a href="#url" class="desktop-mode">
                <span class="vgbcs-icon -desktop">
                    <span class="fa fa-desktop"></span>
                </span>
            </a>
            <a href="#url" class="tablet-mode">
                <span class="vgbcs-icon -tablet">
                    <span class="fa fa-tablet"></span>
                </span>
            </a>
            <a href="#url" class="mobile-mode no-margin-bottom">
                <span class="vgbcs-icon -mobile">
                    <span class="fa fa-mobile"></span>
                </span>
            </a>
        </div>
    </div>
    <div class="right-sidebar-panel-content animated fadeInRight" tabindex="5003"
        style="overflow: hidden; outline: none;">
    </div>
</div>
</div>
</div>-->


<!-- Top Menu 1 -->
<?php include 'assets/include/navbar.php';?>

<section class="vgbcs-about-breadcrum">
  <div class="breadcrum-bg py-sm-5 py-4">
    <div class="container py-lg-3">
      <h2>About Us</h2>
      <p><a href="index.php">Home</a> &nbsp; / &nbsp; About</p>
    </div>
  </div>
</section>
<!---728x90--->

<div class="vgbcs-about1 py-5 editContent" id="about">
  <div class="container py-md-5">
    <div class="heading text-center mx-auto">
      <h3 class="head">Who We Are</h3>
      <p class="my-3 head"><b> DHATRIANS</b> <br></p>
        <p>“Never Doubt that a small group of thoughtful, committed youths can change the world. Indeed it’s the only thing that ever has.” This defines - Dhatri Patra, a non-governmental organisation serving for basic requirements of individuals and animals, to uplift their standards of living. We have a vision that brings hope, a mission that brings a change and values that brings integrity.</p>
    </div>
    <div class="aboutgrids row mt-5 pt-3">
      <div class="col-lg-6 aboutgrid1">
        <h4 class="editContent">start one of our programme today and help people in need</h4>
        <p class="editContent">We serve all over 50+ rural and slum areas in Bangalore. Started in 2022, we focus on satisfying the basic needs of individual's, animals and inspire youths to join for creating an inclusive society around us. Our team continues to prove itself with a great level of personal commitment, dedication and strives to serve in all the ways it can and as long as it can.</p>

          <!-- <div class="story-info editContent">
            <h5><span class="fa fa-check" aria-hidden="true"></span> <a class="editContent"href="services-single.html">
             Worldwide charity programs </a>
            </h5>
          </div> -->

          <!-- <div class="story-info editContent">
            <h5><span class="fa fa-check" aria-hidden="true"></span> <a class="editContent"href="services-single.html">
               Awesome volunteers </a>
            </h5>
          </div> -->

          <!-- <div class="story-info editContent">
            <h5><span class="fa fa-check" aria-hidden="true"></span> <a class="editContent"href="services-single.html">
              Leading volunteer groups</a>
            </h5>
          </div> -->

          <!-- <div class="story-info editContent">
            <h5><span class="fa fa-check" aria-hidden="true"></span> <a class="editContent"href="services-single.html">
              Charity programs for childrens</a>
            </h5>
          </div> -->

          

          <!-- <div class="story-info editContent">
            <h5><span class="fa fa-check" aria-hidden="true"></span> <a class="editContent"href="services-single.html">
              Leading volunteer groups</a>
            </h5>
          </div> -->
      </div>
      <div class="col-lg-6 aboutgrid2 mt-lg-0 mt-5">
        <img src="assets/images/group.JPG" alt="about image" class="img-fluid" />
      </div>
    </div>
  </div>
</div>
<!---728x90--->

<section class="vgbcs-about3">
    <div class="call-vv-action py-5 editContent">
      <div class="container py-lg-3">
        <div class="ab-top text-center">
          <div class="float-lt">
            <h3 class="hny-title editContent">Are you ready to volunteer?
              </h3>
            <p class="editContent">start one of our programme today and help people in need</p>
          </div>
          <div class="float-rt mt-3">
            <ul class="buttons">
              <li class="phone editContent"><span class="fa fa-volume-control-phone" aria-hidden="true"></span> <a class="editContent"
                  href="tel:+91 6363558713">+91 6363558713</a>
              </li>
           
             
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!---728x90--->

<section class="vgbcs-features-3">
	<!-- /features -->
		<div class="features py-5" id="services">
            <div class="container py-md-3">
			<div class="heading text-center mx-auto">
				<h3 class="head">What We Do</h3>
				<p class="my-3 head"> "During the Covid-19 Pandemic, we the young graduates initiated to help people in need who are hugely affected by the pandemic by providing food."<br>"We started distributing food twice a week and distributed almost 1000+ food packets to needy "<br>
By the time we started this, we realized that not only humans but even animals were hugely affected by the pandemic, so we along with helping the needy started to feed the stray pet</p>
			  </div>
			<div class="fea-gd-vv row mt-5 pt-3">	
			   <div class="float-lt feature-gd col-lg-4 col-md-6">	
					 <div class="icon"> <span class="fa fa-file-text-o" aria-hidden="true"></span></div>
					 <div class="icon-info">
						<h5><a href="index.php">Happy Donners</a></h5>
						<!--<p> Lorem ipsum dolor sit amet, consectetur adipisicingelit, sed do eiusmod tempor incididunt  </p>
						<a href="services-single.html" class="red mt-3">Read More </a>-->
					</div>				 
				</div>	
				<div class="float-mid feature-gd col-lg-4 col-md-6 mt-md-0 mt-5">	
					 <div class="icon"> <span class="fa fa-laptop" aria-hidden="true"></span></div>
					 <div class="icon-info">
						<h5><a href="index.php">Custom donation program</a></h5>
						<!---<p> Lorem ipsum dolor sit amet, consectetur adipisicingelit, sed do eiusmod tempor incididunt  </p>
						<a href="services-single.html" class="red mt-3">Read More </a>-->
					</div>
			 </div> 
				<div class="float-rt feature-gd col-lg-4 col-md-6 mt-lg-0 mt-5">	
					 <div class="icon"> <span class="fa fa-clone" aria-hidden="true"></span></div>
					 <div class="icon-info">
						<h5><a href="index.php">Various Projects</a></h5>
						<!--<p> Lorem ipsum dolor sit amet, consectetur adipisicingelit, sed do eiusmod tempor incididunt  </p>
						<a href="services-single.html" class="red mt-3">Read More </a>-->
					</div>
			 </div>	 
			 <div class="float-lt feature-gd col-lg-4 col-md-6 mt-5">	
					 <div class="icon"> <span class="fa fa-bullseye" aria-hidden="true"></span></div>
					 <div class="icon-info">
						<h5><a href="about.php">Societial ideas</a>
						</h5>
						<!---<p> Lorem ipsum dolor sit amet, consectetur adipisicingelit, sed do eiusmod tempor incididunt  </p>
						<a href="services-single.html" class="red mt-3">Read More </a>-->
					</div>
					 
				</div>	
				<div class="float-mid feature-gd col-lg-4 col-md-6 mt-5">	
					 <div class="icon"> <span class="fa fa-cog" aria-hidden="true"></span></div>
					 <div class="icon-info">
						<h5><a href="about.php">Awards</a>
						</h5>
						<!---<p> Lorem ipsum dolor sit amet, consectetur adipisicingelit, sed do eiusmod tempor incididunt  </p>
						<a href="services-single.html" class="red mt-3">Read More </a>--->
					</div>
			 </div> 
				<div class="float-rt feature-gd col-lg-4 col-md-6 mt-5">	
					 <div class="icon"> <span class="fa fa-truck" aria-hidden="true"></span></div>
					 <div class="icon-info">
						<h5><a href="about.php">Volunteer Programs</a>
						</h5>
						<!---<p> Lorem ipsum dolor sit amet, consectetur adipisicingelit, sed do eiusmod tempor incididunt  </p>
						<a href="services-single.html" class="red mt-3">Read More </a>-->
					</div>
			 </div>		 				 
		  </div>  
		 </div>
	   </div>
   <!-- //features -->
</section>
<!-- grids block 5 -->
<?php include 'assets/include/footer.php';?>
	</body>


<!-- Mirrored from demo.vgbcsayouts.com/demosWTR/Freedom/29-02-2020/volunteer-freedom-demo_Free/1818462156/web/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 18 Jan 2022 12:14:20 GMT -->
</html>
<!-- // grids block 5 -->
