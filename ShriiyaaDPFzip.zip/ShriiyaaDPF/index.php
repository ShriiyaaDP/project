<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<?php include 'assets/include/analytics.php';?>
<!-- <?php include 'raghu/gurl.php';?>  -->
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">
    <title>DHATRI PATRA | Home </title>
    <!-- web fonts -->
    <link href="http://fonts.googleapis.com/css?family=Karla:400,700&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <!-- //web fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-freedom.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.2/owl.carousel.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  </head>
  <body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<div id="codefund"><!-- fallback content --></div>
<script src="../../../../../../../codefund.io/properties/441/funder.js" async="async"></script>

<!-- Global site tag (gtag.js) - Google Analytics Removed -->
    
<meta name="robots" content="noindex">
<body>

<!-- New toolbar-->
<style>
* {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}


#vgbcsDemoBar.vgbcs-demo-bar {
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 9999;
  padding: 40px 5px;
  padding-top:70px;
  margin-bottom: 70px;
  background: #0D1326;
  border-top-left-radius: 9px;
  border-bottom-left-radius: 9px;
}

#vgbcsDemoBar.vgbcs-demo-bar a {
  display: block;
  color: #e6ebff;
  text-decoration: none;
  line-height: 24px;
  opacity: .6;
  margin-bottom: 20px;
  text-align: center;
}

#vgbcsDemoBar.vgbcs-demo-bar span.vgbcs-icon {
  display: block;
}

#vgbcsDemoBar.vgbcs-demo-bar a:hover {
  opacity: 1;
}

#vgbcsDemoBar.vgbcs-demo-bar .vgbcs-icon svg {
  color: #e6ebff;
}
#vgbcsDemoBar.vgbcs-demo-bar .responsive-icons {
  margin-top: 30px;
  border-top: 1px solid #41414d;
  padding-top: 40px;
}
#vgbcsDemoBar.vgbcs-demo-bar .demo-btns {
  border-top: 1px solid #41414d;
  padding-top: 30px;
}
#vgbcsDemoBar.vgbcs-demo-bar .responsive-icons a span.fa {
  font-size: 26px;
}
#vgbcsDemoBar.vgbcs-demo-bar .no-margin-bottom{
  margin-bottom:0;
}
.toggle-right-sidebar span {
  background: #0D1326;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #e6ebff;
  border-radius: 50px;
  font-size: 26px;
  cursor: pointer;
  opacity: .5;
}
.pull-right {
  float: right;
  position: fixed;
  right: 0px;
  top: 70px;
  width: 90px;
  z-index: 99999;
  text-align: center;
}
/* ============================================================
RIGHT SIDEBAR SECTION
============================================================ */

#right-sidebar {
  width: 90px;
  position: fixed;
  height: 100%;
  z-index: 1000;
  right: 0px;
  top: 0;
  margin-top: 60px;
  -webkit-transition: all .5s ease-in-out;
  -moz-transition: all .5s ease-in-out;
  -o-transition: all .5s ease-in-out;
  transition: all .5s ease-in-out;
  overflow-y: auto;
}

/* ============================================================
RIGHT SIDEBAR TOGGLE SECTION
============================================================ */

.hide-right-bar-notifications {
  margin-right: -300px !important;
  -webkit-transition: all .3s ease-in-out;
  -moz-transition: all .3s ease-in-out;
  -o-transition: all .3s ease-in-out;
  transition: all .3s ease-in-out;
}

/*===============================================
carsouel silder
=================================================*/
.carousel-inner img {
    width: 100%;
    height: 100%;


@media (max-width: 992px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.desktop-mode{
      display: none;

  }
}
@media (max-width: 767px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.tablet-mode{
      display: none;

  }
}
@media (max-width: 568px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.mobile-mode{
      display: none;
  }
  #vgbcsDemoBar.vgbcs-demo-bar .responsive-icons {
      margin-top: 0px;
      border-top: none;
      padding-top: 0px;
  }
  #right-sidebar,.pull-right {
      width: 90px;
  }
  #vgbcsDemoBar.vgbcs-demo-bar .no-margin-bottom-mobile{
      margin-bottom: 0;
  }
}
</style>
 <?php include 'assets/include/navbar.php';?>
<!------slider code-------------->


<section class="vgbcs-main-slider" id="home">
  <!-- main-slider -->
  <div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <!-- <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li> -->
  </ul>
  <!--<div class="carousel-inner">-->
    <!--<div class="carousel-item active">-->
     <!-- <a href="https://play.decathlon.in/event-details/Causeathon-Independence-Run-for-a-Cause-Decathlon-Hennur/e84419ea-2f91-11ee-89a6-33253233d221?utm_source=sharebutton&utm_medium=decathlon_play_partner_app&utm_campaign=externalshare"><img  src="assets/images/decathlon.png" alt="Decathlon poster" width="1100" height="500"></a>-->
      <!--<div class="carousel-caption">-->
      <!--  <a class="btn btn-secondary btn-theme2 mt-3" href="https://play.decathlon.in/event-details/Causeathon-Independence-Run-for-a-Cause-Decathlon-Hennur/e84419ea-2f91-11ee-89a6-33253233d221?utm_source=sharebutton&utm_medium=decathlon_play_partner_app&utm_campaign=externalshare">BOOk NOW</a>-->
        <!-- <a class="btn btn-secondary btn-theme2 mt-3" href="https://rzp.io/l/P6pOEI09kZ">Donate Now</a> -->
        <!-- <form ><script src="https://checkout.razorpay.com/v1/payment-button.js" data-payment_button_id="pl_JHXTkJs7UhJ2D3" async> </script> </form> -->
      <!-- </div> -->
    <!--</div>-->
     <div class="carousel">
      <img src="2.png" alt="Chicago" width="1600" height="400">
      <div class="carousel-caption">
      
     <a class="btn btn-secondary btn-theme2 mt-3" href="#"> Join Us</a>
      
     </div>   
    </div> 
     <div class="carousel-item">
      <img src="3.png" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <a class="btn btn-secondary btn-theme2 mt-3" href="contact.php">Contact Us</a>
      </div>   
    </div>
  </div> 
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<!------- end of new---------->
  <!-- //script -->
  <!-- /main-slider -->
</section>

<!---728x90--->
<section class="vgbcs-feature-2">
	<div class="grid top-bottom py-5">
		<div class="container py-md-5">
			<div class="heading text-center mx-auto">
				<h3 class="head">We Can Change The World</h3>
				<p class="my-3 head"> “Never Doubt that a small group of thoughtful, committed youths can change
the world. Indeed it’s the only thing that ever has.”<br></p>
<p style="color:darkred;">This defines - Dhatri Patra</p>

			</div>
			<div class="middle-section row mt-5 pt-3">
				<div class="three-grids-columns col-md-4">

					<h4 ><span>01</span> Mission</h4>
					<p >To develop appropriate programs to generate and raise funds for development .</p><br><br>
				</div>
				<div class="three-grids-columns col-md-4 mt-md-0 mt-5">

					<h4 ><span>02</span> Vision</h4>
					<p >To help create an environment with equal opportunity the development of the Children, Family and Communities</p><br>

				</div>
				<div class="three-grids-columns col-md-4 mt-md-0 mt-5">

					<h4 ><span>03</span> Values</h4>
					<p >To support the education of orphans,brilliant but needy Children <br>To support the development of deprived Communities.</p>
				</div>

			</div>
		</div>
	</div>
</section>
<!---728x90--->

 <section class="block-5 pb-5">
    <div class="container pb-md-5">
        <section class="timeline row">
            <div class="col-lg-4">
                <div class="tl-item">
                    <div class="tl-bg" style="background-image: url(assets/images/education2.jpg)"></div>
                    <div class="tl-content">
                        <h1>Help Children</h1>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 my-4 my-lg-0">
                <div class="tl-item">
                    <div class="tl-bg" style="background-image: url(assets/images/donation1.jpg)"></div>
                    <div class="tl-content">
                        <h1 class="f3 text--accent ttu">Development Matters</h1>

                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="tl-item">
                    <div class="tl-bg" style="background-image: url(assets/images/dog123.jpg)"></div>
                    <div class="tl-content">
                        <h1 class="f3 text--accent ttu">Environment</h1>

                    </div>
                </div>
            </div>
        </section>
    </div>
</section>
<!---728x90--->

<!-- specifications -->
<section class="vgbcs-specifications-9">
    <div class="main-w3 py-5" id="stats">
        <div class="container py-md-5">
            <div class="main-cont-wthree-fea row">
                <div class="grids-speci1 col-lg-3 col-6 text-center">
                    <div class="spec-2">

                        <h3 class="title-spe">150+</h3>
                        <p>Donations</p>
                    </div>
                </div>
                <div class="grids-speci1 midd-eff-spe col-lg-3 col-6 text-center">
                    <div class="spec-2">

                        <h3 class="title-spe">100+</h3>
                        <p>Volunteers</p>
                    </div>
                </div>
                <div class="grids-speci1 las-but col-lg-3 col-6  mt-lg-0 mt-4 text-center">
                    <div class="spec-2">

                        <h3 class="title-spe">6</h3>
                        <p>Campaigns Conducted</p>
                    </div>
                </div>
                <div class="grids-speci1 las-t col-lg-3 col-6  mt-lg-0 mt-4 text-center">
                    <div class="spec-2">

                        <h3 class="title-spe">10000+</h3>
                        <p>Food Distributed</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- //specifications -->
</section>
<!-- features-4 block -->
<section class="vgbcs-index1" id="about">
	<div class="calltoaction-20  py-5 editContent">
		<div class="container py-md-3">
			<div class="heading text-center mx-auto">
				<h3 class="head">Join Us</h3>
				<p class="my-3 head"> </p>
			</div>
			<div class="calltoaction-20-content row mt-5 pt-3">
				<div class="column center-align-self col-lg-12 py-4 py-lg-5 pl-4 pl-lg-5 pr-4 pr-lg-5">
					<h5 class="editContent">Become a Volunteer</h5>
					<p class="more-gap editContent"></p>

					<a href="https://docs.google.com/forms/u/3/d/e/1FAIpQLSfLi6y6-mTEJChIQfXdD5pHsH1j-V_xEjkIZFV8byvDVwb_qQ/viewform?usp=send_form" class="theme-button btn mt-4">Sign Up</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- features-4 block -->
<!--customers-7-->
<section class="vgbcs-customers-8" id="testimonials">
    <div class="customers_sur py-5">
        <div class="container py-md-5">
            <div class="heading text-center mx-auto">
                <h3 class="head text-white">Words From Our Clients</h3>
                <p class="my-3 head text-white"> I Can't Change the direction of the wind,But i can adjust my sails to always reach my destination</p>
            </div>
            <div class="customers-top_sur row mt-5 pt-3">
                <div class="customers-left_sur col-md-4">
                    <div class="customers_grid">
                        <h4>Humanity</h4>
                        <p class="sub-test">"An individual has not started living until he can rise above the narrow confines of his individualistic concerns to the broader concerns of all humanity.”<br> </p>
                    </div>
                    <div class="customers-bottom_sur row">
                        <div class="custo-img-res col-3">
                            <img src="assets/images/photo.jpg" alt=" " class="img-responsive">
                        </div>
                        <div class="custo_grid col-9">
                            <h5 class="text-white">Raghavendra M</h5>
                            <span>President</span>
                        </div>

                    </div>
                </div>
                <div class="customers-middle_sur col-md-4 mt-md-0 mt-4">
                    <div class="customers_grid">
                        <h4>Funding</h4>
                        <!-- <p class="sub-test">“The problem is that rich are getting richer by not giving and poor and getting poorer by not receiving.”<br><br>"Effort, great, small.”</p> -->
                        <p class="sub-test">“The value of money isn't what it can buy, but how many it can help. It is the duty of the previlidged to support the underpreviledged”<br>"Every penny matters”</p>
                    </div>
                    <div class="customers-bottom_sur row">
                        <div class="custo-img-res col-3">
                            <img src="assets/images/photo2.jpg" alt=" " class="img-responsive">
                        </div>
                        <div class="custo_grid col-9">
                            <h5 class="text-white">Varun Govind</h5>
                            <span>Volunteer</span>
                        </div>

                    </div>
                </div>
                <div class="customers-middle_sur col-md-4 mt-md-0 mt-4">
                    <div class="customers_grid">
                        <h4>Kindness</h4>
                        <p class="sub-test">“Love and kindness are never wasted. They always make a difference. They bless the one who receives them, and they bless you, the giver.“Be kind whenever possible. It is always possible.” <br></p>
                    </div>
                    <div class="customers-bottom_sur row">
                        <div class="custo-img-res col-3">
                            <img src="assets/images/photo1.jpg" alt=" " class="img-responsive">
                        </div>
                        <div class="custo_grid col-9">
                            <h5 class="text-white">Karan Khadka</h5>
                            <span>Guest</span>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--//customers-7-->
<section class="grids-4" id="news">
    <div id="grids4-block" class="py-5">
        <div class="container py-md-5">
            <div class="heading text-center mx-auto">
                <h3 class="head">WE WORK FOR</h3>
            </div>
            <div class="row mt-5 pt-3">
                <div class="grids4-info  col-lg-4 col-md-6">

                    <div class="info-bg editContent">
                        <a href="blog.html"><img src="assets/images/fooddonation.jpg" class="img-fluid" alt=""></a>
                        <h5 class="mt-4 mb-1 editContent"><a class="editContent" href="https://dhatripatra.blogspot.com/">Distribution of food to the homeless</a>
                        </h5>
                        <li><a href="https://dhatripatra.blogspot.com/"> Read More</a></li>
                    </div>
                </div>
                <div class="grids4-info col-lg-4 col-md-6 mt-md-0 mt-4">

                    <div class="info-bg editContent">
                        <a href="blog.html"><img src="assets/images/education3.jpg" class="img-fluid" alt=""></a>
                        <h5 class="mt-4 mb-1 editContent"><a class="editContent" href="https://dhatripatra.blogspot.com/">Basic education for underprivileged
                            </a></h5>
                            <li><a href="https://dhatripatra.blogspot.com/"> Read More</a></li>
                    </div>
                </div>
                <div class="grids4-info col-lg-4 col-md-6 offset-lg-0 offset-md-3 mt-lg-0 mt-4">

                    <div class="info-bg editContent">
                        <a href="blog.html"><img src="assets/images/dog1.jpg" class="img-fluid" alt=""></a>
                        <h5 class="mt-4 mb-1 editContent"><a class="editContent" href="https://dhatripatra.blogspot.com/">Care for Dogs</a></h5>
                        <li><a href="https://dhatripatra.blogspot.com/"> Read More</a></li>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include 'assets/include/footer.php';?>
<!-- Footer -->
	</body>


</html>
