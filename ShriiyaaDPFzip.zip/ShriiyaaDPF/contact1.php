<!-- //contact address -->
<!-- contact form -->
<div class="contacts12-main col-lg-7 pr-lg-5 pr-3">
    <h5>Write Us</h5>
    <p class="mt-3">Have any Queries? Let us know. We will clear it for you at the best.</p>
    <form method="POST" class="main-input mt-5" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="top-inputs">
            <input type="text" placeholder="Name" name="name" id="name" required="">
        </div>
        <div class="top-inputs">
            <input type="email" name="email" placeholder="Email" id="email" required="">
        </div>
        <textarea placeholder="Message" name="message" id="message" required=""></textarea>
        <div class="text-left">
            <button type="submit" name="submit" value="Send" class="btn btn-theme2">Send</button>
        </div>
    </form>
</div>






<?php
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// $result=$name.$name.$subject.$body;
echo $result='support@dhatripatra.com?subject='.$message.'&message=Hi My name is : '.$name.'%0d%0aemail :'.$email.'%0d%0a'.$message;
header('Location: '.$result);
?>