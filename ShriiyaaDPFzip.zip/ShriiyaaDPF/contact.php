<?php include 'assets/include/mailer.php';?>
<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="ha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

<head>
<link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- remove -->
    
 
<!-- remove -->
<?php include 'assets/include/analytics.php';?>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Dhatri Patra| Contact</title>
    <!-- web fonts -->
    <link href="http://fonts.googleapis.com/css?family=Karla:400,700&amp;display=swap" rel="stylesheet">
    <!-- //web fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-freedom.css">
  </head>
  <body>
<script src='../../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:vgbcsayoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>



<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:vgbcsayoutscom');
  	}
})();
</script>
<!--<script>(function(v,d,o,ai){ai=d.createElement("script");ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, "//a.vdo.ai/core/vgbcsayouts_V2/vdo.ai.js?vdo=34");</script>-->
<div id="codefund"><!-- fallback content --></div>
<script src="../../../../../../../codefund.io/properties/441/funder.js" async="async"></script>

<!-- Global site tag (gtag.js) - Google Analytics Removed -->
<script async src='../../../../../../js/autotrack.js'></script>

<meta name="robots" content="noindex">
<body>
	<!-- Demo bar start -->
  <link rel="stylesheet" href="../../../../../../assests/css/font-awesome.min.css">
<!-- New toolbar-->
<style>
* {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}


#vgbcsDemoBar.vgbcs-demo-bar {
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 9999;
  padding: 40px 5px;
  padding-top:70px;
  margin-bottom: 70px;
  background: #0D1326;
  border-top-left-radius: 9px;
  border-bottom-left-radius: 9px;
}

#vgbcsDemoBar.vgbcs-demo-bar a {
  display: block;
  color: #e6ebff;
  text-decoration: none;
  line-height: 24px;
  opacity: .6;
  margin-bottom: 20px;
  text-align: center;
}

#vgbcsDemoBar.vgbcs-demo-bar span.vgbcs-icon {
  display: block;
}

#vgbcsDemoBar.vgbcs-demo-bar a:hover {
  opacity: 1;
}

#vgbcsDemoBar.vgbcs-demo-bar .vgbcs-icon svg {
  color: #e6ebff;
}
#vgbcsDemoBar.vgbcs-demo-bar .responsive-icons {
  margin-top: 30px;
  border-top: 1px solid #41414d;
  padding-top: 40px;
}
#vgbcsDemoBar.vgbcs-demo-bar .demo-btns {
  border-top: 1px solid #41414d;
  padding-top: 30px;
}
#vgbcsDemoBar.vgbcs-demo-bar .responsive-icons a span.fa {
  font-size: 26px;
}
#vgbcsDemoBar.vgbcs-demo-bar .no-margin-bottom{
  margin-bottom:0;
}
.toggle-right-sidebar span {
  background: #0D1326;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #e6ebff;
  border-radius: 50px;
  font-size: 26px;
  cursor: pointer;
  opacity: .5;
}
.pull-right {
  float: right;
  position: fixed;
  right: 0px;
  top: 70px;
  width: 90px;
  z-index: 99999;
  text-align: center;
}
/* ============================================================
RIGHT SIDEBAR SECTION
============================================================ */

#right-sidebar {
  width: 90px;
  position: fixed;
  height: 100%;
  z-index: 1000;
  right: 0px;
  top: 0;
  margin-top: 60px;
  -webkit-transition: all .5s ease-in-out;
  -moz-transition: all .5s ease-in-out;
  -o-transition: all .5s ease-in-out;
  transition: all .5s ease-in-out;
  overflow-y: auto;
}

/* ============================================================
RIGHT SIDEBAR TOGGLE SECTION
============================================================ */

.hide-right-bar-notifications {
  margin-right: -300px !important;
  -webkit-transition: all .3s ease-in-out;
  -moz-transition: all .3s ease-in-out;
  -o-transition: all .3s ease-in-out;
  transition: all .3s ease-in-out;
}



@media (max-width: 992px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.desktop-mode{
      display: none;

  }
}
@media (max-width: 767px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.tablet-mode{
      display: none;

  }
}
@media (max-width: 568px) {
  #vgbcsDemoBar.vgbcs-demo-bar a.mobile-mode{
      display: none;
  }
  #vgbcsDemoBar.vgbcs-demo-bar .responsive-icons {
      margin-top: 0px;
      border-top: none;
      padding-top: 0px;
  }
  #right-sidebar,.pull-right {
      width: 90px;
  }
  #vgbcsDemoBar.vgbcs-demo-bar .no-margin-bottom-mobile{
      margin-bottom: 0;
  }
}
</style>


<?php include 'assets/include/navbar.php';?>

<!-- Top Menu 1 -->

<section class="vgbcs-contact-breadcrum">
  <div class="breadcrum-bg py-sm-5 py-4">
    <div class="container py-lg-3">
      <h2>Contact Us</h2>
      <p><a href="index.php">Home</a> &nbsp; / &nbsp; Contact</p>
    </div>
  </div>
</section>
<!---728x90--->

<!-- contact -->
<section class="vgbcs-contacts-12" id="contact">
    <div class="contact-top pt-5">
        <div class="container py-md-3">
            <div class="heading text-center mx-auto">
                <h3 class="head">Have you a question?</h3>
                <p class="my-3 head"> IF YOU HAVE ANY QUERIES OR CONCERNS, KINDLY GET BACK TO THE VOLUNTEER TEAM,
WE WILL HELP YOU OUT.</p>
              </div>
            <div class="row cont-main-top mt-5 pt-3">
               
                <!-- contact address -->
               
                <!-- //contact address -->
                 <!-- contact form -->
                 <div class="contacts12-main col-lg-7 pr-lg-5 pr-3">
                    <h5>Write Us</h5>
                        <p class="mt-3">Have any Queries? Let us know. We will clear it for you at the best.</p>
                        <!-- <form action="https://sendmail.vgbcsayouts.com/submitForm" method="post" class="main-input mt-5"> -->
                    <form  method="POST" class="main-input mt-5">
                        <div class="top-inputs">
                            <input type="text" placeholder="Name" name="name" id="name" required="">
                            
                        </div>
                        <div class="top-inputs">
                           
                            <input type="email" name="email" placeholder="Email" id="email" required="">
                        </div>
                       
                        <textarea placeholder="Message" name="message" id="message" required=""></textarea>
                        <div class="text-left">
                        <form id="emailForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <div class="text-left">
        <button type="submit" name="submit" value="Send" class="btn btn-theme2">Send</button>
    </div>
</form>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Email address to send the message to
    $to_email = 'support@dhatripatra.com';
    
    // Subject of the email
    $subject = 'Support Request';
    
    // Body of the email
    $body = 'Please describe your issue or inquiry here.';
    
    // Construct the mailto URL
    $mailto_url = 'mailto:' . urlencode($to_email) . '?subject=' . urlencode($subject) . '&body=' . urlencode($body);
    
    // Redirect the user to the mailto URL
    header("Location: $mailto_url");
    exit;
}
?>
                        </div>
                    </form>
                </div>
                <!-- //contact form -->
                <div class="contact col-lg-5 mt-lg-0 mt-5">
                    <div class="cont-subs">
                        <h5>Contact Information</h5>
                        <p class="mt-3">Contact Us </p>
                       <div class="con-top mt-5">
                        <div class="cont-add ">
                            <div class="cont-add-lft">
                                <span class="fa fa-map-marker" aria-hidden="true"></span>
                           </div>
                           <div class="cont-add-rgt">
                            <h4>Address</h4>
                            <a href="https://maps.app.goo.gl/GAe2VfDRLFpCy2Hf9">
                              <p class="contact-text-sub">KRISTU JAYANTI COLLEGE</p></a>
                        </div>
                    </div><br>
                   <!-- <div class="cont-add ">
                        <div class="cont-add-lft">
                            <span class="fa fa-map-marker" aria-hidden="true"></span>
                       </div>
                       <div class="cont-add-rgt">
                        <h4>Adress-2</h4>
                        <p class="contact-text-sub">K Naryana Puram</p>
                    </div>
                </div>-->
                        <div class="cont-add">
                            <div class="cont-add-lft">
                                <span class="fa fa-envelope" aria-hidden="true"></span>
                           </div>
                           <div class="cont-add-rgt">
                            <h4>Email</h4>
                            <a href="mailto:support@dhatripatra.org">
                                <p class="contact-text-sub">support@dhatripatra.org</p><br>                            </a>
                        </div>
                    </div>
                    <!--<div class="cont-add">
                        <div class="cont-add-lft">
                            <span class="fa fa-envelope" aria-hidden="true"></span>
                       </div>
                       <div class="cont-add-rgt">
                        <h4>Email-2</h4>
                        <a href="mailto:info@example.com">
                            <p class="contact-text-sub">info@example.com</p>
                        </a>
                    </div>-->
                </div>
                        <div class="cont-add">
                            <div class="cont-add-lft">
                                 <span class="fa fa-whatsapp" aria-hidden="true"></span>
                            </div>
                            <div class="cont-add-rgt">
                                 <h4>Text</h4>
                                 <a href="https://wa.me/916363558713?text=Hi">
                                    <p class="contact-text-sub">+91 6363558713</p>
                                 </a>
                            </div>
                        </div>
                        <!--<div class="cont-add">
                            <div class="cont-add-lft">
                                 <span class="fa fa-phone" aria-hidden="true"></span>
                            </div>
                            <div class="cont-add-rgt">
                                 <h4>Phones-2</h4>
                                 <a href="tel:+7-800-999-800">
                                    <p class="contact-text-sub">+7-800-999-800</p>
                                 </a>
                            </div>
                        </div>-->
                    </div>

                    </div>
                </div>
            </div>
        </div>
		<!---728x90--->

        <!-- map -->
        <div class="map">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d242.91560549882973!2d77.64260442397503!3d13.05795617190594!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae17578c79da7d%3A0xe96dcd8e2b982f8e!2sKristu%20Jayanti%20College%2C%20Autonomous!5e0!3m2!1sen!2sin!4v1711533043095!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"> width="600" height="450" style="border:0;" allowfullscreen=></iframe>
        </div>
        <!-- //map -->
    </div>
</section>
<!-- //contact -->
<!---728x90--->

<!-- grids block 5 -->
<!-- grids block 5 -->

<?php include 'assets/include/footer.php';?>
	</body>


<!-- Mirrored from demo.vgbcsayouts.com/demosWTR/Freedom/29-02-2020/volunteer-freedom-demo_Free/1818462156/web/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 18 Jan 2022 12:14:44 GMT -->
</html>
<!-- // grids block 5 -->
