<?php include 'assets/include/mailer.php';?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dhatri Patra| Internship</title>
    <!-- web fonts -->
    <link href="http://fonts.googleapis.com/css?family=Karla:400,700&amp;display=swap" rel="stylesheet">
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-freedom.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="ha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
    <!-- Navbar -->
    <?php include 'assets/include/navbar.php';?>

    <!-- Internship Form -->
    <section class="vgbcs-contacts-12" id="internship-form">
        <div class="contact-top pt-5">
            <div class="container py-md-3">
                <div class="heading text-center mx-auto">
                    <h3 class="head">Apply for Internship</h3>
                    <p class="my-3 head">Please fill out the form below to apply for an internship.</p>
                </div>
                <div class="row cont-main-top mt-5 pt-3">
                    <div class="contacts12-main col-lg-7 pr-lg-5 pr-3">
                        <form method="POST" class="main-input mt-5" enctype="multipart/form-data">
                            <div class="top-inputs">
                                <input type="text" placeholder="Full Name" name="fullname" id="fullname" required>
                            </div>
                            <div class="top-inputs">
                                <input type="email" name="email" placeholder="Email" id="email" required>
                            </div>
                            <div class="top-inputs">
                                <input type="tel" name="phone" placeholder="Phone Number" id="phone" required>
                            </div>
                            <div class="top-inputs">
                                <input type="file" name="resume" id="resume" required>
                                <label for="resume">Upload Resume</label>
                            </div>
                            <textarea placeholder="Why do you want to intern with us?" name="message" id="message" rows="4" required></textarea>
                            <div class="text-left">
                                <button type="submit" name="submit" value="Submit" class="btn btn-theme2">Submit Application</button>
                            </div>
                        </form>
                    </div>
                    <!-- Contact Information -->
                    <div class="contact col-lg-5 mt-lg-0 mt-5">
                        <div class="cont-subs">
                            <h5>Contact Information</h5>
                            <p class="mt-3">Contact Us</p>
                            <div class="con-top mt-5">
                                <div class="cont-add">
                                    <div class="cont-add-lft">
                                        <span class="fa fa-map-marker" aria-hidden="true"></span>
                                    </div>
                                    <div class="cont-add-rgt">
                                        <h4>Address</h4>
                                        <a href="https://maps.app.goo.gl/GAe2VfDRLFpCy2Hf9">
                                            <p class="contact-text-sub">KRISTU JAYANTI COLLEGE</p>
                                        </a>
                                    </div>
                                </div>
                                <div class="cont-add">
                                    <div class="cont-add-lft">
                                        <span class="fa fa-envelope" aria-hidden="true"></span>
                                    </div>
                                    <div class="cont-add-rgt">
                                        <h4>Email</h4>
                                        <a href="mailto:support@dhatripatra.org">
                                            <p class="contact-text-sub">support@dhatripatra.org</p>
                                        </a>
                                    </div>
                                </div>
                                <div class="cont-add">
                                    <div class="cont-add-lft">
                                        <span class="fa fa-whatsapp" aria-hidden="true"></span>
                                    </div>
                                    <div class="cont-add-rgt">
                                        <h4>Text</h4>
                                        <a href="https://wa.me/916363558713?text=Hi">
                                            <p class="contact-text-sub">+91 6363558713</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- // Contact Information -->
                </div>
            </div>
        </div>
    </section>
    <!-- // Internship Form -->

    <!-- Footer -->
    <?php include 'assets/include/footer.php';?>

</body>
</html>
